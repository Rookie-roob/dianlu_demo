function  [number] = voltages_number(data1,num)
% 得到电压源的数量
number=0;
 for i=1:num
 if data1{i}(1)=='V'
 number=number+1;
  end
 end
end


function [p] = rightside(data1,data2,data3,data4,num1,num2,num3)
%num2为节点的数量，num1为元件的数量，num3为电压源的数量
I=zeros(num2,1);
E=zeros(num3,1);
for i=1:num1
     if data1{i}(1)=='I'
        x=data2(i);
        y=data3(i);
        z=data4(i);
        for j=1:num2
            if j==y
            I(j,1)=I(j,1)+z;
            end
            if j==x
            I(j,1)=I(j,1)-z;
            end
        end             
     end
if data1{i}(1)=='V'
        string=data1{i}(2);
        k=str2num(string);
        l=data4(i);
        for j=1:num3
            if j==k
            E(j,1)=abs(l);
            end
        end             
     end
end
    p=[I;E];
end


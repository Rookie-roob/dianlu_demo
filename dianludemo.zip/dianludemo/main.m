%说明：对于U来说，左负右正，大于0，左小右大；左正右负，小于0，左小右大。对于I来说，电流流入为正，箭头指向的为正极。左上为n*n的电阻矩阵，右上为n*m的电压矩阵，左下为右上矩阵的转置，右下为0矩阵。
%对于右上的矩阵，如果第i个电压源的正极连接到k，则矩阵中的（k，i）为1。如果第i个电压源的负极连接到k，则矩阵中的（k，i）为-1。
clc;clear;
name=file_name();
%文件的读取
wenjian=fopen(name,'r');
data=textscan(wenjian,'%s %d %d %f');
fclose(wenjian);
%根据元组将数据进行预处理
data1=data{1};
data2=data{2};
data3=data{3};
data4=data{4};
%元件的数量
number_of_components=length(data1);
%节点的数量
number_of_nodes=data3(1);
for i=1:number_of_components
    if number_of_nodes<data3(i)
        number_of_nodes=data3(i);
    end
end
%电压源的数量
number_of_voltages=voltages_number(data1,number_of_components);
%电流源的数量
number_of_current=current_number(data1,number_of_components);
%构造电阻矩阵
matrix_Resistance=zao_G(data1,data2,data3,data4,number_of_components,number_of_nodes);
%构造电压矩阵
matrix_Voltage=zao_V(data1,data2,data3,data4,number_of_components,number_of_nodes,number_of_voltages);
%构造电压矩阵的转置矩阵
matrix_Voltage_spin=matrix_Voltage';
%构造零矩阵
matrix_zero=zeros(number_of_voltages);
%方程的系数
xishu=[matrix_Resistance,matrix_Voltage;matrix_Voltage_spin,matrix_zero];
%方程等式另一侧的值
xiangliang=rightside(data1,data2,data3,data4,number_of_components,number_of_nodes,number_of_voltages);
%解方程
jie=(xishu^-1)*xiangliang;
%节点电压值和流经电压源的电流值
node_voltages=jie(1:number_of_nodes)
voltage_current=abs(jie(number_of_nodes+1:(number_of_nodes+number_of_voltages)))



        

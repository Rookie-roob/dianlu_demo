function [V] = zao_V(data1,data2,data3,data4,num1,num2,num3)
V=zeros(num2,num3);
temp=0;
for i=1:num1
    if data1{i}(1)=='V' 
       temp=temp+1;
       x=data2(i);
       y=data3(i);
       z=data4(i);
     for j=1:num2
     for k=1:num3
         if (k==temp)
           if(z>0)
               if j==x
              V(j,k)=-1;
               else if j==y
               V(j,k)=1;
                   end
               end
          else if z<0
              if(j==x)
              V(j,k)=1;
              else if j==y
              V(j,k)=-1;
                  end
              end
              end
           end
         end
     end
     end
    end
end
end


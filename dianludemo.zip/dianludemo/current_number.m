function [number] = current_number(data1,num)
%求电流源的数量
number=0;
 for i=1:num
 if data1{i}(1)=='I'
 number=number+1;
  end
 end
end



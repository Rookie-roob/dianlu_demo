function [G]  = zao_G(data1,data2,data3,data4,num1,num2)
G=zeros(num2,'double');
for i=1:num1
    if data1{i}(1)=='R'
        qian=data2(i);
        hou=data3(i);
        g=(data4(i)).^-1;
        for j=1:num2
            for k=1:num2
                if (j==k && (qian==j || hou==j))
                    G(j,k)=G(j,k)+g;
        else if (j~=k && ((qian==j && hou==k) || (qian==k && hou==j)))       
                G(j,k)=G(j,k)-g;
            end
                end
            end
        end
    end
end
end

